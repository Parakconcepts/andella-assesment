# hello-world
Just to follow all righteousness program
Yeah, you're all welcome to my repo.
I am launching this to highlight projects im working on
I am currently working on getting right the concepts for 3 projects
A digital register, A crush mobile game and an app for local navigation
